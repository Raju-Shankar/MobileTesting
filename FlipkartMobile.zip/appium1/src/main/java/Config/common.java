package Config;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class common {
    public static int LOAD_TIMEOUT = 10;
    public static AppiumDriver driver;

    public common(AppiumDriver<MobileElement> driver)
    {
        this.driver = driver;
    }

    public static WebElement waitForElement(WebElement arg) {
        waitForPageToLoad(arg);
        WebElement el = arg;
        return el;
    }
    public  static void waitForPageToLoad(WebElement id) {
        WebDriverWait wait = new WebDriverWait(driver, LOAD_TIMEOUT);
        try {
            wait.until(ExpectedConditions.visibilityOf(id));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
