package object;

import io.appium.java_client.MobileElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class flipkartPages{

    @ AndroidFindBy(xpath ="//android.widget.RelativeLayout/android.widget.LinearLayout[1]/androidx.recyclerview.widget.RecyclerView/android.widget.RelativeLayout[6]/android.widget.RelativeLayout/android.widget.ImageView[1]")
    public MobileElement  Flipkart_select_Language;


    @ AndroidFindBy(id = "com.flipkart.android:id/select_btn")
    public MobileElement Flipkart_ContinueButton;

    @ AndroidFindBy(id = "com.google.android.gms:id/cancel")
    public MobileElement Flipkart_CancelButton;

    @ AndroidFindBy(id = "com.flipkart.android:id/tv_right_cta")
    public MobileElement Flipkart_EmailLogin;

    @ AndroidFindBy(id = "com.flipkart.android:id/phone_input")
    public MobileElement Flipkart_TextBox;

    @ AndroidFindBy(id = "com.flipkart.android:id/button")
    public MobileElement Flipkart_ContinueButton1;

    @ AndroidFindBy(id = "com.flipkart.android:id/search_widget_textbox")
    public MobileElement Flipkart_SearchBox;


    @ AndroidFindBy(accessibility= "Search grocery products")
    public MobileElement Flipkart_SearchBox_searchPage;




    @ AndroidFindBy(xpath = "//android.view.ViewGroup[1]/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.view.ViewGroup[1]/android.view.ViewGroup")
    public MobileElement  Flipkart_FirstProd;

    @ AndroidFindBy(xpath = "//android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.widget.TextView[1]")
    public MobileElement  Flipkart_productDesc;


    @ AndroidFindBy(xpath = "//android.view.ViewGroup[2]/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup[3]/android.widget.TextView")
    public MobileElement  Flipkart_AddToCart;



    @ AndroidFindBy(xpath = "//android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.view.ViewGroup[3]/android.view.ViewGroup[3]/android.widget.TextView")
    public MobileElement  Flipkart_GoToCart;



    @ AndroidFindBy(xpath = "//android.view.ViewGroup[1]/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.view.ViewGroup[1]/android.widget.TextView[1]")
    public MobileElement  Flipkart_cartProdDesc;


    @ AndroidFindBy(xpath = "//androidx.recyclerview.widget.RecyclerView/android.widget.RelativeLayout[1]")
    public MobileElement Flipkart_FirstProduct;







}
