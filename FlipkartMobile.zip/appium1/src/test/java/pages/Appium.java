    package pages;

    import com.aventstack.extentreports.ExtentReports;
    import com.aventstack.extentreports.ExtentTest;
    import com.aventstack.extentreports.Status;
    import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
    import io.appium.java_client.AppiumDriver;
    import io.appium.java_client.MobileElement;
    import io.appium.java_client.TouchAction;
    import io.appium.java_client.android.AndroidDriver;
    import io.appium.java_client.pagefactory.AppiumFieldDecorator;
    import io.appium.java_client.service.local.AppiumDriverLocalService;
    import io.appium.java_client.service.local.AppiumServiceBuilder;
    import java.io.File;
    import java.io.IOException;
    import java.time.Duration;

    import Config.common;
    import io.appium.java_client.touch.offset.PointOption;
    import object.flipkartPages;
    import org.openqa.selenium.remote.DesiredCapabilities;
    import org.openqa.selenium.support.PageFactory;
    import org.testng.Assert;
    import org.testng.annotations.AfterClass;

    import static org.testng.Assert.assertTrue;

    public class Appium extends common {

        public static AppiumDriver driver;
        public static AppiumDriverLocalService server;

         flipkartPages referenceObj;

        public Appium(AppiumDriver<MobileElement> driver) throws IOException {
            super(driver);
            if (referenceObj == null)
            {
                referenceObj = new flipkartPages();
            }
            PageFactory.initElements(new AppiumFieldDecorator(driver, Duration.ofMillis(10)), referenceObj);

        }

        public  void Enter_language() throws InterruptedException {

            ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("extent.html");

            // create ExtentReports and attach reporter(s)
            ExtentReports extent = new ExtentReports();
            extent.attachReporter(htmlReporter);


            ExtentTest test = extent.createTest("FlipkartDemo", "Sample description");

            //click on english lang
            referenceObj.Flipkart_select_Language.click();
            test.log(Status.INFO, "language selected");
            //wait for continue button
            waitForElement(referenceObj.Flipkart_ContinueButton);
            //click on cotinue
            referenceObj.Flipkart_ContinueButton.click();
            //login with mail id
            waitForElement(referenceObj.Flipkart_CancelButton);
            referenceObj.Flipkart_CancelButton.click();
            referenceObj.Flipkart_EmailLogin.click();
            //Enter mail id
            waitForElement(referenceObj.Flipkart_TextBox);
            referenceObj.Flipkart_TextBox.sendKeys("");//Enter mail id
            //click on cotinue
            referenceObj.Flipkart_ContinueButton1.click();
            //Enter password
            referenceObj.Flipkart_TextBox.sendKeys("");//Enter password
            //click on continue
            referenceObj.Flipkart_ContinueButton1.click();
            test.log(Status.PASS, "Login successfull");
            //wait for search text box
            waitForElement(referenceObj.Flipkart_SearchBox);
            referenceObj.Flipkart_SearchBox.click();
            //search for product in search page
            waitForElement(referenceObj.Flipkart_SearchBox_searchPage);
            referenceObj.Flipkart_SearchBox_searchPage.sendKeys("Bose sports Earbuds ");
            //get product desc
            referenceObj.Flipkart_SearchBox_searchPage.click();
            referenceObj.Flipkart_FirstProduct.click();
            test.log(Status.INFO, "Found product");
            waitForElement(referenceObj.Flipkart_FirstProd);
            referenceObj.Flipkart_FirstProd.click();
            waitForElement(referenceObj.Flipkart_productDesc);
            String prodDesc = referenceObj.Flipkart_productDesc.getText().substring(0,36).trim();
            System.out.println("prod desc is " + prodDesc);
            //Add to cart
            TouchAction action = new TouchAction(driver);
            action.tap(PointOption.point(248,2127)).perform();
            test.log(Status.INFO, "Product added to cart successfull");
    //      referenceObj.Flipkart_AddToCart.click();
            Thread.sleep(4000);
            //Go to cart yet to be done
            TouchAction action1 = new TouchAction(driver);
            action1.tap(PointOption.point(248,2127)).perform();
            //Check prod desc in cart
            waitForElement(referenceObj.Flipkart_cartProdDesc);
            String Prod_desc_cart = referenceObj.Flipkart_cartProdDesc.getText().trim();
            //cart check product desc path-/android.view.ViewGroup[1]/android.widget.ScrollView/android.view.ViewGroup/android.view.ViewGroup/android.view.ViewGroup[2]/android.view.ViewGroup/android.view.ViewGroup[1]/android.widget.TextView[1]
            System.out.println("prod desc in cart is  " + Prod_desc_cart);

            Assert.assertEquals(prodDesc,Prod_desc_cart,"desc are not same");
            test.log(Status.PASS, "Prod desc are same");
            //Uninstall app
            driver.removeApp("com.flipkart.android");
            test.log(Status.PASS, "App uninstalled succesfully");
            extent.flush();

        }



        public static void main(String args[]) throws IOException, InterruptedException {


            AppiumServiceBuilder serviceBuilder = new AppiumServiceBuilder();
            // Use any port, in case the default 4723 is already taken (maybe by another Appium server)
            serviceBuilder.usingPort(4723);
            serviceBuilder.withIPAddress("127.0.0.1");
            // Tell serviceBuilder where node is installed. Or set this path in an environment variable named NODE_PATH
            serviceBuilder.usingDriverExecutable(new File("C:/Program Files/nodejs/node.exe"));
            // Tell serviceBuilder where Appium is installed. Or set this path in an environment variable named APPIUM_PATH
            serviceBuilder.withAppiumJS(new File("/AppData/Roaming/npm/node_modules/appium/build/lib/main.js"));//Appium js path

            server = AppiumDriverLocalService.buildService(serviceBuilder);
            server.start();

            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability("deviceName", "Redmi");
            capabilities.setCapability("platformVersion", "10");
            capabilities.setCapability("platformName", "Android");
            capabilities.setCapability("appPackage", "com.flipkart.android");
            capabilities.setCapability("appActivity", "com.flipkart.android.SplashActivity");

            driver = new AndroidDriver<MobileElement>(server.getUrl(), capabilities);
            Thread.sleep(5000);

            Appium instance= new Appium(driver);
            instance.Enter_language();

        }


        @AfterClass
        public static void stopAppiumServer()
        {
            server.stop();

        }
    }
